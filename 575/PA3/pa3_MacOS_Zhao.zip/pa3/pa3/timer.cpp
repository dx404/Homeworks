//
//  timer.cpp
//  pa3
//
//  Created by Duo Zhao on 3/27/13.
//  Copyright (c) 2013 Duo Zhao. All rights reserved.
//

#include "timer.h"
#ifndef GL_TIME_ELAPSED
    #define GL_TIME_ELAPSED 0x88BF
#endif

Timer::Timer(){
    gTotalTimeElapsed = 0;
    gTotalFrames = 0;
}

void Timer::init_timer(){
	glGenQueries(1, &gTimer);
}

void Timer::start_timing()
{
	glBeginQuery(GL_TIME_ELAPSED, gTimer);
}

float Timer::stop_timing(){
	glEndQuery(GL_TIME_ELAPSED);
    
	GLint available = GL_FALSE;
	while (available == GL_FALSE)
		glGetQueryObjectiv(gTimer, GL_QUERY_RESULT_AVAILABLE, &available);
    
	GLint result;
	glGetQueryObjectiv(gTimer, GL_QUERY_RESULT, &result);
    
	float timeElapsed = result / (1000.0f * 1000.0f * 1000.0f);
	return timeElapsed;
}
