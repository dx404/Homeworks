//
//  load_mesh.cpp
//  pa3
//
//  Created by Duo Zhao on 3/26/13.
//  Copyright (c) 2013 Duo Zhao. All rights reserved.
//

#include "load_mesh.h"

#include <iostream>
#include <fstream>
#include <iomanip>

#include <cstdlib>
#include <cstring>
#include <cfloat>

/**
 * starting the implementation of the Mesh Parser
 */
MeshParser::MeshParser(std::string fileName){
	this->load_mesh(fileName);
	gPosList = NULL;
	gNorList = NULL;
	gTriIndexBuffer = NULL;
    getSerialize();
}

MeshParser::~MeshParser(){
	gPositions.clear();
	gNormals.clear();
	gTriangles.clear();
	delete gPosList;
	delete gNorList;
	delete gTriIndexBuffer;
    
}

void MeshParser::tokenize(char* string, std::vector<std::string>& tokens, const char* delimiter){
	char* token = strtok(string, delimiter);
	while (token != NULL)
	{
		tokens.push_back(std::string(token));
		token = strtok(NULL, delimiter);
	}
}

int MeshParser::face_index(const char* string){
	int length = strlen(string);
	char* copy = new char[length + 1];
	memset(copy, 0, length+1);
	strcpy(copy, string);
    
	std::vector<std::string> tokens;
	tokenize(copy, tokens, "/");
	delete[] copy;
	if (tokens.front().length() > 0 && tokens.back().length() > 0 && atoi(tokens.front().c_str()) == atoi(tokens.back().c_str()))
	{
		return atoi(tokens.front().c_str());
	}
	else
	{
		printf("ERROR: Bad face specifier!\n");
		exit(0);
	}
}

void MeshParser::load_mesh(std::string fileName){
	std::ifstream fin(fileName.c_str());
	if (!fin.is_open())
	{
		printf("ERROR: Unable to load mesh from %s!\n", fileName.c_str());
		exit(0);
	}
    
	float xmin = FLT_MAX;
	float xmax = -FLT_MAX;
	float ymin = FLT_MAX;
	float ymax = -FLT_MAX;
	float zmin = FLT_MAX;
	float zmax = -FLT_MAX;
    
	while (true){
		char line[1024] = {0};
		fin.getline(line, 1024);
        
		if (fin.eof())
			break;
        
		if (strlen(line) <= 1)
			continue;
        
		std::vector<std::string> tokens;
		tokenize(line, tokens, " ");
        
		if (tokens[0] == "v")
		{
			float x = atof(tokens[1].c_str());
			float y = atof(tokens[2].c_str());
			float z = atof(tokens[3].c_str());
            
			xmin = std::min(x, xmin);
			xmax = std::max(x, xmax);
			ymin = std::min(y, ymin);
			ymax = std::max(y, ymax);
			zmin = std::min(z, zmin);
			zmax = std::max(z, zmax);
            
			Vector3 position = {x, y, z};
			gPositions.push_back(position);
		}
		else if (tokens[0] == "vn")
		{
			float x = atof(tokens[1].c_str());
			float y = atof(tokens[2].c_str());
			float z = atof(tokens[3].c_str());
			Vector3 normal = {x, y, z};
			gNormals.push_back(normal);
		}
		else if (tokens[0] == "f")
		{
			unsigned int a = face_index(tokens[1].c_str());
			unsigned int b = face_index(tokens[2].c_str());
			unsigned int c = face_index(tokens[3].c_str());
			Triangle triangle;
			triangle.indices[0] = a - 1;
			triangle.indices[1] = b - 1;
			triangle.indices[2] = c - 1;
			gTriangles.push_back(triangle);
		}
	}
    
	fin.close();
    
    std::cout << "Loaded mesh from " << fileName << ". (" <<
        gPositions.size() << " vertices, " <<
        gNormals.size() << " normals, " << 
        gTriangles.size() << " triangles)" <<
    std::endl;
    
    std::cout << "Mesh bounding box is: " <<
        std::setprecision(4) <<
            "(" <<  xmin << ", " << ymin << ", " << zmin << ") to " <<
            "(" <<  xmax << ", " << ymax << ", " << zmax << ")" <<
    std::endl;
    
}


void MeshParser::getSerialize(){
    gPosListSize = gPositions.size() * 3;
    gNorListSize = gNormals.size() * 3;
    gTriIndexBufferSize = gTriangles.size() * 3;
    
	gTriIndexBuffer = new GLushort[gTriIndexBufferSize];
	gNorList = new GLfloat[gNorListSize];
	gPosList = new GLfloat[gPosListSize];
    
	for (unsigned int i = 0; i < gTriangles.size(); i++){
		gTriIndexBuffer[3 * i] 	= gTriangles[i].indices[0];
		gTriIndexBuffer[3 * i + 1] = gTriangles[i].indices[1];
		gTriIndexBuffer[3 * i + 2] = gTriangles[i].indices[2];
	}
    
	for (unsigned int i = 0; i < gNormals.size(); i++){
		gNorList[3 * i] 	= gNormals[i].x;
		gNorList[3 * i + 1] = gNormals[i].y;
		gNorList[3 * i + 2] = gNormals[i].z;
	}
    
	for (unsigned int i = 0; i < gPositions.size(); i++){
		gPosList[3 * i] 	= gPositions[i].x;
		gPosList[3 * i + 1] = gPositions[i].y;
		gPosList[3 * i + 2] = gPositions[i].z;
	}
    
}

