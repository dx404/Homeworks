//
//  load_mesh.h
//  pa3
//
//  Created by Duo Zhao on 3/26/13.
//  Copyright (c) 2013 Duo Zhao. All rights reserved.
//

#ifndef __pa3__load_mesh__
#define __pa3__load_mesh__

#include <vector>
#ifdef __APPLE__
    #include <openGL/gl.h>
#else
    #include <GL/gl.h>
#endif
#include <string>

struct Vector3 { float x, y, z;};

struct Triangle { unsigned int indices[3]; };

class MeshParser{
    
public:
	std::vector<Vector3> gPositions;
	std::vector<Vector3> gNormals;
	std::vector<Triangle> gTriangles;
    
	GLfloat *gPosList;
	GLfloat *gNorList;
	GLushort *gTriIndexBuffer;
    
    int gPosListSize;
    int gNorListSize;
    int gTriIndexBufferSize;
    
	MeshParser();
	MeshParser(std::string);
	~MeshParser();
	void load_mesh(std::string);
	void getSerialize();
    
private:
	void tokenize(char*, std::vector<std::string>&, const char*);
	int face_index(const char*);
};

#endif /* defined(__pa3__load_mesh__) */
