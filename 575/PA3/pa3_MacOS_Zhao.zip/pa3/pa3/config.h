//
//  config.h
//  pa3
//
//  Created by Duo Zhao on 3/27/13.
//  Copyright (c) 2013 Duo Zhao. All rights reserved.
//

#ifndef pa3_config_h
#define pa3_config_h
#include <string>
/*
 * imme_draw is for rendering the bunny using OpenGL's immediate mode
 * vao_vbo_draw is for rendering the bunny using VAOs and VBOs
 * ele_draw is for testing using glDrawElement() with neither VAOs nor VBOs
 * beta is for testing, using OpenGL build-in functions
 */
enum Draw_Method {imme_draw, vao_vbo_draw, ele_draw, beta};


//default configuration
Draw_Method draw_method(imme_draw);
bool timerEnabled(false);

std::string filePath = "data/bunny.obj";
Timer *timer;

#endif
