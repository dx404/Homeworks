//
//  timer.h
//  pa3
//
//  Created by Duo Zhao on 3/27/13.
//  Copyright (c) 2013 Duo Zhao. All rights reserved.
//

#ifndef __pa3__timer__
#define __pa3__timer__

#include <iostream>
#ifdef __APPLE__
    #include <openGL/gl.h>
#else
    #include <GL/glew.h>
    #include <GL/glut.h>
    #include <GL/glext.h>
#endif

class Timer{
public: 
    float gTotalTimeElapsed;
    int gTotalFrames;
    GLuint gTimer;
    
    Timer(void);
    void init_timer(void);
    void start_timing(void);
    float stop_timing(void);
};


#endif /* defined(__pa3__timer__) */
