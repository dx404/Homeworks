//============================================================================
// Name        : comp575_pa3_Zhao.cpp
// Author      : Duo zhao
// Version     :
// Copyright   : programming assignment 3
//============================================================================


#include <iostream>
#include <cstdlib>
#include <GLUT/glut.h>
#ifdef __APPLE__
    #define glGenVertexArrays glGenVertexArraysAPPLE
    #define glBindVertexArray glBindVertexArrayAPPLE
#endif

#include "load_mesh.h"
#include "timer.h"
#include "config.h"

using namespace std;

#define BUFFER_OFFSET(offset) ((void*)(offset))

const int WIN_WIDTH = 512, WIN_HEIGHT = 512;

MeshParser *mesh;

void init(void);
void display(void);
void reshape(int width, int height);
void drawInImmediateMode(void);
void drawInVertexArrays(void);
void drawByVAOnVBO(void);

int main(int argc, char *argv[]) {
	cout << "Welcome to Duo's Programming Assignment 3" << endl;
    cout << "Options for Drawing Methods : " << endl;
    cout << "\t 1- for rendering the bunny using OpenGL's immediate mode" << endl;
    cout << "\t 2- for endering the bunny using VAOs and VBOs" << endl;
    

    if (argc >= 2){
        switch (atoi(argv[1])) {
            case 1:
                draw_method = imme_draw;
                cout << "\nMethod 1 drawing! (immediate mode)\n" << endl;
                break;
            case 2:
                draw_method = vao_vbo_draw;
                cout << "\nMethod 2 drawing! (VAOs and VBOs)\n" << endl;
                break;
            case 3:
                draw_method = ele_draw;
                cout << "\nMethod III drawing! (Testing Only, Drawing without VAOs or VBOs)\n" << endl;
                break;
            case 4:
                draw_method = beta;
                cout << "\nMethod IV drawing! (Testing Only, Drawing a wired Cube)\n" << endl;
                break;
            default:
                draw_method = imme_draw;
                cout << "\nMethod 1 drawing! (immediate mode, default method, unspecified options)\n" << endl;
                break;
        }
    }
   else {
        draw_method = imme_draw;
        cout << "\nMethod I drawing! (immediate mode, default method, no command-line para feeded)\n" << endl;
   }
    //if timer is set
    timerEnabled = (argc >= 3 && atoi(argv[2]) == 1);
    if (timerEnabled){
        timer = new Timer();
        cout << "Timer is enabled" << endl;
    }
    
    if (argc >= 4) filePath = string(argv[3]);
    
    mesh = new MeshParser(filePath);

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL);
	glutInitWindowPosition(WIN_WIDTH/2, WIN_HEIGHT/2);
	glutInitWindowSize(WIN_WIDTH, WIN_HEIGHT);
	glutCreateWindow("PA 3: OpenGL Bunny");
    
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
    
    if (timerEnabled)
        timer->init_timer();
	
    glutMainLoop();
	
    delete mesh;
    if (timerEnabled)
        delete timer;
	return 0;
}

void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
    
	GLfloat lmodel_ambient[] = {0.2, 0.2, 0.2, 1};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
    
	GLfloat light_ambient[] = {0.0, 0.0, 0.0, 1};
	GLfloat light_diffuse[] = {1, 1, 1, 1};
	GLfloat light_specular[] = {0, 0, 0, 1};
	GLfloat light_position[] = {1, 1, 1, 0}; //directional light
    
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    
	GLfloat mat_ambient[] = {1, 1, 1, 1};
	GLfloat mat_diffuse[] = {1, 1, 1, 1};
	GLfloat mat_specular[] = {0, 0, 0, 1};
	GLfloat mat_shininess[] = {0};
    
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
    
    
	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);
    
	glEnable(GL_NORMALIZE);
	glDisable(GL_CULL_FACE);
    
}

void display() {
    if (timerEnabled)
        timer->start_timing();
    
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0f, 1.0f, 1.0f);
	glLoadIdentity();
    
	gluLookAt(0, 0, 0, 0, 0, -1, 0, 1, 1);
	glTranslatef(0.1, -1, -1.5);
	glScalef(10, 10, 10);
    
    if (timerEnabled)
        timer->start_timing();

    
    switch (draw_method) {
        case imme_draw:
            glBegin(GL_TRIANGLES);
            drawInImmediateMode();
            glEnd();
            break;
        
        case vao_vbo_draw:
            drawByVAOnVBO();
            break;
        
        case ele_draw:
            drawInVertexArrays();
            break;
        
        case beta:
            glutWireCube(.1);
            break;
            
        default:
            glutWireCube(.1);
            break;
    }

    
    if (timerEnabled){
        float timeElapsed = timer->stop_timing();
        timer->gTotalFrames++;
        timer-> gTotalTimeElapsed += timeElapsed;
        float fps = timer->gTotalFrames / timer->gTotalTimeElapsed;
        char msg[1024] = {0};
        sprintf(msg, "OpenGL Bunny: %0.2f FPS, gtf=%d, gtte=%f", fps, timer->gTotalFrames, timer->gTotalTimeElapsed);
        glutSetWindowTitle(msg);
    }
    
    glutPostRedisplay();
    glutSwapBuffers();
}

void reshape(int width, int height){
	cout << "width: " << width << " height: " << height << endl;
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-0.1, 0.1, -0.1, 0.1, 0.1, 1000);
	glMatrixMode(GL_MODELVIEW);
}

void drawInImmediateMode(){
	Triangle *tri;
	int k0, k1, k2;
	Vector3 *v0, *v1, *v2;
	Vector3 *vn0, *vn1, *vn2;
	for (unsigned int i = 0; i < mesh->gTriangles.size(); i++){
		tri = &mesh->gTriangles[i];
		k0 = tri->indices[0];
		k1 = tri->indices[1];
		k2 = tri->indices[2];
        
		v0 = &mesh->gPositions[k0];
		v1 = &mesh->gPositions[k1];
		v2 = &mesh->gPositions[k2];
        
		vn0 = &mesh->gNormals[k0];
		vn1 = &mesh->gNormals[k1];
		vn2 = &mesh->gNormals[k2];
        
		glNormal3f(vn0->x, vn0->y, vn0->z);
		glVertex3f(v0->x, v0->y, v0->z);
        
		glNormal3f(vn1->x, vn1->y, vn1->z);
		glVertex3f(v1->x, v1->y, v1->z);
        
		glNormal3f(vn2->x, vn2->y, vn2->z);
		glVertex3f(v2->x, v2->y, v2->z);
	}
}

/*not in use*/
void drawInVertexArrays(){    
	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);
    
	glNormalPointer(GL_FLOAT, 0, mesh->gNorList);
	glVertexPointer(3, GL_FLOAT, 0, mesh->gPosList);
	glDrawElements(
                   GL_TRIANGLES,
                   3 * mesh->gTriangles.size(),
                   GL_UNSIGNED_SHORT,
                   mesh->gTriIndexBuffer
                   );
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
}


void drawByVAOnVBO(){    
    enum {BunnyMesh, NumVAOs};
    GLuint VAO[NumVAOs];
	enum {Vertices, Normals, Elements, NumVBOs};
	GLuint bufferIDs[NumVBOs] = {0, 1, 2};
    
    glGenVertexArrays(1, VAO);
	glBindVertexArray(VAO[BunnyMesh]);
    
    glGenBuffers(1, &bufferIDs[Vertices]);
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[Vertices]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * mesh->gPosListSize, mesh->gPosList, GL_STATIC_DRAW);
	glVertexPointer(3, GL_FLOAT, 0, BUFFER_OFFSET(0));
	glEnableClientState(GL_VERTEX_ARRAY);
    
    glGenBuffers(1, &bufferIDs[Normals]);
	glBindBuffer(GL_ARRAY_BUFFER, bufferIDs[Normals]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * mesh->gNorListSize, mesh->gNorList, GL_STATIC_DRAW);
	glNormalPointer(GL_FLOAT, 0, BUFFER_OFFSET(0));
	glEnableClientState(GL_NORMAL_ARRAY);
    
    glGenBuffers(1, &bufferIDs[Elements]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIDs[Elements]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLshort) * mesh->gTriIndexBufferSize, mesh->gTriIndexBuffer, GL_STATIC_DRAW);
    
    /*3 * mesh->gTriangles.size()*/ 
	glDrawElements(GL_TRIANGLES, mesh->gTriIndexBufferSize, GL_UNSIGNED_SHORT, BUFFER_OFFSET(0));
    
    glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_VERTEX_ARRAY);
    #ifdef __APPLE__
    glDisableClientState(GL_ELEMENT_ARRAY_APPLE);
    #endif
    
    glDeleteBuffers(1, &bufferIDs[Vertices]);
    glDeleteBuffers(1, &bufferIDs[Normals]);
    glDeleteBuffers(1, &bufferIDs[Elements]);
}
