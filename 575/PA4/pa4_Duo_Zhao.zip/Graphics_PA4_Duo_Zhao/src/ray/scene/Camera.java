package ray.scene;

public class Camera {

}
