package pipeline;

import pipeline.gui.Pixel;
import pipeline.math.BaryCen;

public class Rasterizer {
	Scene scene;
	public Pixel[][] screenPixels;
	public int width, height;
	
	
	public Rasterizer(Scene scene){
		this.scene = scene;
		width = scene.screenWidth;
		height = scene.screenHeight;
		screenPixels = new Pixel[width][height];
		createBlackScreen();
	}
	
	public void rasterize_a(){
		createBlackScreen();
		BaryCen bc;
		int arrayToMark[][];
		int x, y; // coordinates to mark scene.gNumTriangles
		for (int tri_index = 0 ; tri_index < scene.gNumTriangles; tri_index++){
			int base = 3 * tri_index;
//			try{
				int k0 = scene.gIndexBuffer[base];
				int k1 = scene.gIndexBuffer[base + 1];
				int k2 = scene.gIndexBuffer[base + 2];
				
				System.out.println(scene.vOnScreen[k0]);
				bc = new BaryCen(scene.vOnScreen[k0], scene.vOnScreen[k1], scene.vOnScreen[k2]);
				arrayToMark = bc.getInteriors();
				for (int i = 0; arrayToMark[i][0] >= 0 /*&& arrayToMark[i][1] >= 0*/  ; i++){
					x = arrayToMark[i][0];
					y = arrayToMark[i][1];
					screenPixels[y][x].set(1, 1, 1);
				}
//			}
//			catch(java.lang.ArrayIndexOutOfBoundsException e){
//				System.out.println("base=" + base);
//			}
		}
	}
	
	private void createBlackScreen(){
		for (int y = 0; y < height; y++)
			for (int x = 0; x < width; x++)
				screenPixels[y][x] = new Pixel(0,0,0);
	}
	
}
