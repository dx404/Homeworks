package pipeline;

public class Shader {

}
