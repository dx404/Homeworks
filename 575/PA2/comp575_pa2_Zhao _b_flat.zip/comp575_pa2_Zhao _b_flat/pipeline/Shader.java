package pipeline;

import javax.vecmath.Vector3f;

public class Shader {

	
	Scene scene;
	
	
}
