package miniJava.CodeGenerator;

public class PatchLine {
	public int line;
	public int info;
	public PatchLine(int line, int info){
		this.line = line;
		this.info = info;
	}
}
